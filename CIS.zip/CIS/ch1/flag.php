<?php
    require("main.php");
    $fl = new Flag();
    $ch = $fl->getFlag();
?>