<?php

    echo "<h3>Get hidden username and password, then obtain the flag</h3>";
    echo "<br>";
    echo "<p>Your username : user</p>";
    echo "<br>";
    echo "<p>Your Password : password</p>";
    echo "<br>";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Challenge 3</title>
</head>
<body>
    <a href="login.php">Start Challenge</a>
</body>
</html>