<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main Page</title>
</head>
<body>
    <a href="ch1/index.php">Challenge One</a><br>
    <a href="ch2/index.php">Challenge Two</a><br>
    <a href="ch3/index.php">Challenge Three</a><br>
</body>
</html>